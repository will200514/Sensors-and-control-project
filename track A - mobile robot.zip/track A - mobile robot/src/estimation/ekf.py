"""Extended Kalman filter: wheel odometry prediction + single-marker camera pose updates."""
import numpy as np
from .. import config as C
from ..model.diffdrive import f_motion, F_motion, G_motion, wrap, body_to_wheels

# estimates the uncertainty in the wheel odometry i.e. forward and turning speeds
# answers how much error should we expect in the speeds used to predict movement
def odom_covariance(v, w, q_scale=1.0):
    """Covariance of the odometry velocity input, derived from wheel-level noise.

    Wheel surface speeds vL, vR; encoder noise e (sigma_enc) and relative slip eps (sigma_slip, plus
    a per-trial bias sigma_bias that we cannot estimate, so it is folded into the slip term):
        v_err   ~ (e_L + e_R)/2          - (vL eps_L + vR eps_R)/2
        w_err   ~ (e_R - e_L)/b          - (vR eps_R - vL eps_L)/b
    """
    vl, vr = body_to_wheels(v, w)              # converts body speed into left and right wheel speeds
    s2 = C.SIGMA_SLIP ** 2 + C.SIGMA_BIAS ** 2  # two wheel source errors
    var_v = C.SIGMA_ENC ** 2 / 2 + s2 * (vl ** 2 + vr ** 2) / 4
    var_w = 2 * C.SIGMA_ENC ** 2 / C.TRACK ** 2 + s2 * (vl ** 2 + vr ** 2) / C.TRACK ** 2
    cov_vw = s2 * (vr ** 2 - vl ** 2) / (2 * C.TRACK)   # shared slip terms correlate v and w
    return q_scale * np.array([[var_v, cov_vw], [cov_vw, var_w]])


# creates and initiallises the filter
# runs when a file creates an EKF
# x0 = Initial estimated position and heading
# P0 = Initial pose covarience
# cfg = Filter settings, including noise scales, focal length, and rejection threshold
class EKF:
    def __init__(self, x0, P0, cfg):
        self.x = np.array(x0, float)
        self.P = np.array(P0, float)    #stores uncertainty
        self.cfg = cfg
        self.n_updates = 0
        self.n_rejected = 0
        self.last_nis = []
        self.frame_rej = 0
        self.n_recoveries = 0

    #predicts the robots next pose
    # predicts movement and increases uncertainty
    # For example, the wheels might indicate that the robot travelled one metre. 
    # The estimate moves forward by approximately that amount, while the covariance accounts for possible encoder errors and slip.
    def predict(self, u, dt=C.DT):
        F = F_motion(self.x, u, dt)
        G = G_motion(self.x, u, dt)
        Qd = G @ odom_covariance(*u, q_scale=self.cfg.q_scale) @ G.T + np.diag([1e-8, 1e-8, 1e-8])
        self.x = f_motion(self.x, u, dt)
        self.P = F @ self.P @ F.T + Qd



    # establishes the docking frame
    # pose: robots position and heading relative to the docking marker
    # covariance: uncertainty in the camera derived pose
    # method replaces self.x and self.P with these new values
    # mission is responsible for collecting and confirming start up obsevationds before calling this method
    def initialise_dock(self, pose, covariance):
        """One-time frame switch. The acquisition measurement is NOT fused again."""
        self.x = np.array(pose, float).copy()
        self.x[2] = wrap(self.x[2])
        self.P = np.array(covariance, float).copy()
        self.frame_rej = 0




    # corrects the estimate using the camera
    # measurement update step after dock initialisation
    def update_pose(self, pose, covariance):
        """Correct the predicted pose using a camera pose measurement."""

        # Difference between the camera measurement and prediction.
        innovation = np.asarray(pose, dtype=float) - self.x
        innovation[2] = wrap(innovation[2])

        # Combined prediction and measurement uncertainty.
        R = np.asarray(covariance, dtype=float)
        S = self.P + R

        # Reject measurements that disagree too strongly.
        nis = float(innovation @ np.linalg.solve(S, innovation))

        if self.cfg.gate is not None and nis > self.cfg.gate:
            self.n_rejected += 1
            return False

        # Calculate the correction strength and update the pose.
        K = np.linalg.solve(S, self.P.T).T
        self.x += K @ innovation
        self.x[2] = wrap(self.x[2])

        # Joseph covariance update.
        A = np.eye(3) - K
        self.P = A @ self.P @ A.T + K @ R @ K.T
        self.P = 0.5 * (self.P + self.P.T)

        self.n_updates += 1
        self.last_nis.append(nis)
        return True
    # handles repeated rejection of camera observations
    # This function helps the filter recover when its estimate becomes so inaccurate that the measurement gate rejects every observation.
    # makes filter less confident so it accepts measuremetents when 5 have been rejected
    def end_frame(self, n_detected, n_accepted):
        """Lock-out recovery. A gate protects against outliers, but a filter that is genuinely
        wrong rejects every measurement and never recovers. If every detection in 5 consecutive
        camera frames (0.5 s) is rejected, the filter admits it may be lost: inflate P so the
        gate re-opens and the next detections can pull the estimate back."""
        if n_detected == 0:
            return
        self.frame_rej = 0 if n_accepted > 0 else self.frame_rej + 1
        if self.frame_rej >= 5:
            self.P = self.P + np.diag([0.3 ** 2, 0.3 ** 2, np.deg2rad(20.0) ** 2])
            self.frame_rej = 0
            self.n_recoveries += 1

